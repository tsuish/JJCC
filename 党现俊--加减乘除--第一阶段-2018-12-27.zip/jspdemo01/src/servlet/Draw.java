package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.FileOperation;

public class Draw extends HttpServlet{
	
		protected void doGet(HttpServletRequest request, 
				HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html;charset=utf-8");
			request.setCharacterEncoding("utf-8");
			System.out.println("这里是 Draw");
			//index是新牌的位置，value是新牌的内容
			int index = Integer.parseInt(request.getParameter("index").substring(1));
			String value = request.getParameter("value");
			System.out.println("新摸到的牌是："+value);
			//dCard是存放电脑牌的数据文件的名字
			String wCard = "CardME.txt";
			List<String> wList = FileOperation.getFile(wCard);
			//wlength表示玩家的手牌数量
			int wlength = wList.size();
			wList.set(index-1,value);
			FileOperation.writeFile(wCard, wList);
			response.sendRedirect("main.jsp");
		}
		protected void doPost(HttpServletRequest request, 
				HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
		}
}
