package entity;

import java.io.*;
import java.util.*;

public class test {

	public static void main(String[] args) {
		mymain();
	}
	
	public static void mymain(){
		String in="w7";
		String i =in.substring(1);
		System.out.println(i);
		/*System.out.println(FileOperation.haveFile("CardPC.txt"));*/
//		listWrite();
//		try {
//			List<String> pcList = FileOperation.readFile("CardPC.txt");
//			System.out.println(pcList.toString());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}
	
	/**
	 * @author Administrator
	 * @time 2018-12-24
	 * 
	 * @作用 把一个list写入文件
	 * @调用 listWrite();
	 */
	public static void listWrite(){
		List<String> pcList = new ArrayList<String>();
		pcList.add("CardPC10.txt");
		pcList.add("CardPC2.txt");
		pcList.add("CardPC3.txt");
		pcList.add("CardPC4.txt");
		FileOperation.writeFile("CardPC.txt",pcList);
	}
}
