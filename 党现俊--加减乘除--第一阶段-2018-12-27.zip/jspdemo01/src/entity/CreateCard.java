package entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class CreateCard {
	/**
	 * @author dandelion
	 * @time 2018年12月25日下午2:58:54
	 * @作用 随机从52张牌中抽出来一张牌
	 * @调用 String str = CreateOneCard();
	 * @返回值类型 String     例如："HT_13.gif"
	 */
	public static String CreateOneCard() {
		int random1;
		Card card = new Card();
		Random random = new Random();
		random1 = random.nextInt(52)+1;
		return card.getMap().get(random1);
	}
	/**
	 * @author dandelion
	 * @time 2018年12月25日下午2:58:54
	 * @作用 随机抽取给定数量的牌
	 * @调用 List<String> list = CreateCard.CreateElevenCard(11); 
	 * @返回值类型 List<String>
	 */
	public static List<String> CreateElevenCard(int length) {
		List<String> list = new ArrayList<String>();
		for(int i=0;i<length;i++){
			String str = CreateOneCard();
			list.add(str);
		}
		return list;
	}
	public static void main(String[] args) {
		List<String> list = CreateCard.CreateElevenCard(11);
		System.out.println(list);
	}
}
