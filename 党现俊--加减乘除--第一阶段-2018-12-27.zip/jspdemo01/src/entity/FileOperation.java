package entity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;



public class FileOperation {
	/**
	 * @author Administrator
	 * @time 2018-12-24
	 * @作用 创建一个文件
	 * @调用 creatFile("CardPC.txt");  creatFile("CardME.txt");
	 */
	public static void creatFile(String Card){
		File myFilePath = new File("D:\\"+Card);   
		try {
		    if (!myFilePath.exists()) {
		        myFilePath.createNewFile();
			    FileWriter resultFile = new FileWriter(myFilePath);   
			    PrintWriter myFile = new PrintWriter(resultFile);   
			    System.out.println(Card+"文件创建成功");
			    resultFile.close();  
			    myFile.close();
		    }   
		}
		catch (Exception e) {   
		    System.out.println("新建文件操作出错");   
		    e.printStackTrace();   
		}    
	}
	
	/**
	 * @author dandelion
	 * @time 2018-12-25
	 * @作用 能否找到文件
	 * @调用 haveFile("CardPC.txt");  haveFile("CardME.txt");
	 * @返回 能找到文件返回true，不能找到文件返回false
	 */
	public static boolean haveFile(String Card){
		File myFilePath = new File("D:\\"+Card);
		boolean res = false;
		try {
		    if (myFilePath.exists()) {
		    	res = true;
		    }   
		}   
		catch (Exception e) {   
		    System.out.println("找文件操作出错");   
		    e.printStackTrace();   
		}    
		return res;
	}
	/**
	 * @author Administrator
	 * @throws IOException 
	 * @time 2018-12-24
	 * @作用  逐行读取数据,并add到list中返回
	 * @返回值类型  List<String>
	 * @调用 List<String> pcList = readFile("CardPC.txt");
	 */
	public static List<String> readFile(String Card) throws IOException{
		FileReader fr = new FileReader("D:\\"+Card);
		BufferedReader br = new BufferedReader(fr);
		List<String> list = new ArrayList<String>();
		String str = br.readLine();   
		while (str != null) {   
			list.add(str);
			str = br.readLine(); 
		}
		br.close();
		fr.close();
		return list;
	}
	
	/**
	 * @author Administrator
	 * @time 2018-12-24
	 * @作用  将数据写入文件
	 */
	public static void writeFile(String Card, List<String> list){
		try {   
			creatFile(Card);
		    FileWriter fw = new FileWriter("D:\\"+Card);
		    BufferedWriter br = new BufferedWriter(fw);
		    int i=0;
		    for(String str:list){
		    	br.write(str);
		    	br.newLine();
		    	br.flush();
		    	i++;
		    }
		    String str = "背面.jpg";
		    for(;i<10;i++){
		    	br.write(str);
		    	br.newLine();
		    	br.flush();
		    }
		    System.out.println("一共有"+i+"行");
		    fw.close();
		    System.out.println(Card+"文件中覆盖写入完成--writeFile");
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	/**
	 * @author dandelion
	 * @throws IOException 
	 * @time 2018年12月25日下午2:48:34
	 * @作用 从文件中返回电脑或玩家的手牌数据，存放在list中。
	 * 					如果没有文件或文件数量，则生成数据并存入文件。
	 * @调用 FileOperation.getFile(Card);
	 * @返回值类型 List<String>
	 */
	public static List<String> getFile(String Card) throws IOException{
		//Card 存放的是数据文件的名称
		
		//resList是存放电脑或玩家手牌数据的list
		List<String> resList = new ArrayList<String>();
		
		//如果电脑数据文件和玩家数据文件都存在,
		//      		而且电脑数据文件和玩家数据文件至少有一个有数据,
		//		就把从文件中读到的数据放到dList和wList中
		if(FileOperation.haveFile(Card)&&(FileOperation.readFile(Card).size()>0)){
			resList = readFile(Card);
			System.out.println("从文件中得到数据--getFile");
		}else{
			System.out.println("找不到文件或没有数据--getFile");
		}
		return resList;
	}
	/**
	 * @author dandelion
	 * @throws IOException 
	 * @time 2018年12月25日下午3:34:38
	 * @作用 随机产生电脑或玩家的手牌
	 * @调用 FileOperation.setFile(Card);
	 * @返回值类型 List<String>
	 */
	public static List<String> setFile(String Card) throws IOException{
		//Card 存放的是数据文件的名称
		
		//resList是存放电脑或玩家手牌数据的list
		List<String> resList = new ArrayList<String>();
		
		//InitNum是电脑或玩家初始化时的手牌数	
		int i = 0, InitNum = 0;
		//如果是电脑，InitNum手牌有5个。
		//如果是玩家，InitNum手牌有6个。
		if(Card.equals("CardPC.txt")){
			InitNum = 5;
		}else if(Card.equals("CardME.txt")){
			InitNum = 6;
		}
		//作用：得到InitNum个随机的牌
		List<String> list = CreateCard.CreateElevenCard(InitNum); 
		//作用：把得到的InitNum个随机数传给resList
		for(i=0;i<InitNum;i++){
			resList.add(list.get(i));
		}
		System.out.println("setFile自己初始化数据");
		writeFile(Card, resList);
		return resList;
	}
	/**
	 * @author dandelion
	 * @throws IOException 
	 * @time 2018年12月25日下午4:20:14
	 * @作用 随机产生电脑和玩家的手牌，并存入数据文件。
	 * @调用 InitFile()
	 * @返回值类型 List<List<String>>
	 *  				返回list中两个list值，分别是电脑的手牌list数据和玩家的手牌list数据
	 */
	public static List<List<String>> InitFile() throws IOException{
		//dCard是存放电脑牌的数据文件的名字
		String dCard = "CardPC.txt";
		//wCard是存放玩家牌的数据文件的名字
		String wCard = "CardME.txt";
		//初始化list，用来存放随机产生的11个
		List<List<String>> list = new ArrayList<List<String>>();
		System.out.println("InitFile方法已被调用");
		list.add(setFile(dCard));
		list.add(setFile(wCard));
		return list;
	}
}
