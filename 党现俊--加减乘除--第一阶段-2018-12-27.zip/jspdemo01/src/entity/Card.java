package entity;

import java.util.HashMap;
//让数字（1到52）与52张牌一一对应
public class Card {
	HashMap<Integer,String> map=new HashMap<Integer, String>();
	public void init(){
		HashMap<Integer,String> mapInit=new HashMap<Integer, String>();
		Card card = new Card();
		int i=1,key=0;
		String value="";
		for(i=1;i<=52;i++){
			key = i%13+1;
			if(i<=13){
				value = "FK_"+key+".gif";
			}else if(i<=26){
				value = "HT_"+key+".gif";
			}else if(i<=39){
				value = "HX_"+key+".gif";
			}else if(i<=52){
				value = "MH_"+key+".gif";
			}
			mapInit.put(key, value);
			System.out.println(i+"---"+value);
		}
		card.setMap(mapInit);
	}
	public Card() {
		setMap(Card.CardInit());
	}
	public Card(HashMap<Integer, String> map) {
		super();
		this.map = map;
	}
	public HashMap<Integer, String> getMap() {
		return map;
	}

	public void setMap(HashMap<Integer, String> map) {
		this.map = map;
	}
	public static HashMap<Integer,String> CardInit(){
		HashMap<Integer,String> mapInit=new HashMap<Integer, String>();
		int i=1,key=0;
		String value="";
		for(i=1;i<=52;i++){
			if(i<=13){
				key=i;
				value = "FK_"+key+".gif";
			}else if(i<=26){
				key=i-13;
				value = "HT_"+key+".gif";
			}else if(i<=39){
				key=i-26;
				value = "HX_"+key+".gif";
			}else if(i<=52){
				key=i-39;
				value = "MH_"+key+".gif";
			}
			mapInit.put(i, value);
		}
		return mapInit;
	}
}
