package entity;

public class ButtonFunction{
	/**
	 * @author dandelion
	 * @time 2018年12月25日下午2:43:07
	 * @作用 对刷新按钮做出反应
	 * @调用 
	 * @返回 返回
	 */
	public static void flush(){
		
	}
}
